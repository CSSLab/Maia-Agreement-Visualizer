from ._leela_board import LeelaBoard

import numpy as np

def _softmax(x, softmax_temp):
    e_x = np.exp((x - np.max(x))/softmax_temp)
    return e_x / e_x.sum(axis=0)

def eval_board(board_fen, policy_vec, policy_softmax_temp = 1):

    board = LeelaBoard(board_fen)
    legal_uci = [m.uci() for m in board.generate_legal_moves()]
    legal_indexes = board.lcz_uci_to_idx(legal_uci)
    softmaxed = _softmax(policy_vec[legal_indexes], policy_softmax_temp)

    return { m : float(v) for v, m in sorted(zip(softmaxed, legal_uci), reverse = True)}
